# Nginx JSON 日志分析平台

Vector Agent → Kafka → Vector Consumer → Loki → Grafana

## 为什么加 Kafka？

JSON 日志格式每行约 500-1000 字节，高并发下（1万 QPS）每秒写入量约 5-10MB。
直接 Promtail → Loki 存在以下问题：

- **写入抖动**：请求洪峰时 Loki 写入压力激增，直接影响查询性能
- **无缓冲**：Loki 重启或网络抖动导致日志丢失
- **多节点汇聚**：多台机器同时推送，Loki 面临大量并发写入连接

Kafka 作为缓冲层解决了上述问题：客户端只管往 Kafka 写（极低延迟），
Vector Consumer 统一消费并批量写入 Loki（可控速率）。

## 技术选型

| 组件 | 作用 | 说明 |
|------|------|------|
| **Vector Agent** | 客户端 tail → Kafka | 替代 Promtail，原生支持 Kafka output，Rust 编写内存 ~15MB |
| **Kafka** | 消息缓冲队列 | topic: nginx-logs，lz4 压缩，保留 48h |
| **Vector Consumer** | Kafka 消费 → 解析 → Loki | 在服务端运行，批量写入，做字段规范化 |
| **Loki** | 日志聚合存储 | 按 label 索引，30 天保留 |
| **Grafana** | 可视化 Dashboard | 自动导入 Nginx 分析面板 |
| **Kafka UI** | Kafka 消息监控 | 查看 topic lag、消息量 |

## 目录结构

```
nginx-kafka-loki/
├── server/
│   ├── docker-compose.yml
│   ├── .env.example
│   ├── vector/vector.toml          # 服务端 Vector：消费 Kafka → 推 Loki
│   ├── loki/config.yml             # Loki 存储、保留策略、写入优化
│   └── grafana/
│       ├── provisioning/
│       │   ├── datasources/loki.yml
│       │   └── dashboards/default.yml
│       └── dashboards/
│           └── nginx-analytics.json
├── client-linux/
│   ├── docker-compose.yml          # Vector Agent (docker)
│   ├── vector-agent.toml           # tail → Kafka 配置
│   └── .env.example
└── client-windows/
    ├── vector-agent.toml
    └── install.ps1                 # 一键安装 Vector 为 Windows 服务
```

---

## 部署步骤

### 一、服务端

```bash
cd server

# 1. 配置服务器 IP
cp .env.example .env
vim .env   # 设置 SERVER_IP=你的服务器公网/内网IP

# 2. 启动（约等待 1-2 分钟全部就绪）
docker compose up -d

# 3. 检查状态
docker compose ps

# 验证 Loki 就绪
curl http://localhost:3100/ready

# 验证 Kafka 就绪
docker exec nla-kafka kafka-topics --bootstrap-server localhost:9092 --list
```

访问地址：
- **Grafana**: `http://SERVER_IP:3000`（账号 admin，密码见 .env）
- **Kafka UI**: `http://SERVER_IP:8080`

---

### 二、Linux 客户端

```bash
cd client-linux

cp .env.example .env
vim .env    # 设置 KAFKA_BROKERS=SERVER_IP:9093

docker compose up -d

# 查看推送日志
docker compose logs -f vector-agent
```

验证：在 Kafka UI → Topics → nginx-logs，Messages 数量持续增长。

---

### 三、Windows 客户端

以管理员身份运行 PowerShell：

```powershell
cd client-windows

.\install.ps1 `
  -KafkaBrokers "192.168.1.100:9093" `
  -NodeName     "ws01" `
  -NginxLogPath "C:\nginx\logs\access.log"
```

---

## 数据流说明

```
nginx access.log (JSON)
  ↓  [Vector Agent - tail]
  ↓  .message = 原始 JSON 行
  ↓  .agent_host = 节点名
Kafka topic: nginx-logs (lz4 压缩)
  ↓  [Vector Consumer - 服务端]
  ↓  parse_json(.message) → 展开所有字段
  ↓  status_class 标签计算
  ↓  client_ip 真实 IP 提取
  ↓  upstream 字段 "-" → null
  ↓  批量推送（1MB 或 3s）
Loki（按 node/server_name/scheme/request_method/status_class 索引）
  ↓  LogQL 查询
Grafana Dashboard
```

## Loki 标签设计

Vector Consumer 只将以下**低基数**字段设为 Loki 标签：

| 标签 | 来源字段 | 基数 |
|------|---------|------|
| `job` | 固定值 "nginx" | 1 |
| `node` | nginx log 的 node 字段 | 节点数 |
| `server_name` | $server_name | vhost 数 |
| `scheme` | $scheme | 2 (http/https) |
| `request_method` | $request_method | ~5 |
| `status_class` | 由 status 计算 | 5 (1xx-5xx) |

`client_ip`、`uri`、`http_user_agent` 等高基数字段**只放在日志体**，
通过 `| json` 解析后在 LogQL 中过滤，不做 Loki 标签。

## 常用 LogQL

```logql
# 所有日志
{job="nginx", node=~"ws01|ws02"} | json

# 5xx 错误
{job="nginx", status_class="5xx"} | json

# 慢请求（>2秒）
{job="nginx"} | json | request_time > 2

# 某 IP 的请求
{job="nginx"} | json | client_ip = "1.2.3.4"

# P99 响应时间
quantile_over_time(0.99,
  {job="nginx"} | json | unwrap request_time [5m])

# 按 server_name 统计 QPS
sum by (server_name) (
  rate({job="nginx"}[1m])
)

# 上游响应时间（排除无上游）
avg_over_time(
  {job="nginx"} | json
  | upstream_response_time != ""
  | unwrap upstream_response_time [5m])
```

## 常见问题

**Q: Vector Agent 推送失败，连接 Kafka 超时**
- 检查 9093 端口防火墙
- 确认 `.env` 中 `KAFKA_BROKERS` 填写的是可达 IP
- 验证：`telnet SERVER_IP 9093`

**Q: Grafana 面板显示 No data**
- 先在 Explore 查 `{job="nginx"}` 确认 Loki 已有数据
- 检查时间范围，改为"最近 15 分钟"
- 查看 Vector Consumer 日志：`docker logs nla-vector`

**Q: 日志时间和 Grafana 时间不对齐**
- Vector `remap` 中已用 `time_iso8601` 做时间戳解析
- 确认 nginx 日志的时区配置正确

**Q: Kafka 磁盘占满**
- 调整 `docker-compose.yml` 中 `KAFKA_LOG_RETENTION_BYTES`（默认 5GB）
- 或缩短 `KAFKA_LOG_RETENTION_HOURS`（默认 48h）
