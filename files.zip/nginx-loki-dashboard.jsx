import { useState, useEffect, useCallback, useRef } from "react";

// ─── Loki API ────────────────────────────────────────────────────────────────
const LOKI_URL = "http://localhost:3100"; // ← 修改为你的 Loki 地址

async function lokiQuery(query, { start, end, limit = 100, step } = {}) {
  const now = Date.now();
  const s = start ?? now - 30 * 60 * 1000;
  const e = end ?? now;
  const url = new URL(`${LOKI_URL}/loki/api/v1/query_range`);
  url.searchParams.set("query", query);
  url.searchParams.set("start", Math.floor(s / 1000) + "000000000");
  url.searchParams.set("end", Math.floor(e / 1000) + "999999999");
  url.searchParams.set("limit", limit);
  if (step) url.searchParams.set("step", step);
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Loki ${res.status}: ${await res.text()}`);
  return res.json();
}

async function lokiMetric(query, { start, end, step = "60s" } = {}) {
  const now = Date.now();
  const s = start ?? now - 60 * 60 * 1000;
  const e = end ?? now;
  const url = new URL(`${LOKI_URL}/loki/api/v1/query_range`);
  url.searchParams.set("query", query);
  url.searchParams.set("start", Math.floor(s / 1000) + "000000000");
  url.searchParams.set("end", Math.floor(e / 1000) + "999999999");
  url.searchParams.set("step", step);
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Loki ${res.status}: ${await res.text()}`);
  return res.json();
}

async function lokiInstant(query, { time } = {}) {
  const url = new URL(`${LOKI_URL}/loki/api/v1/query`);
  url.searchParams.set("query", query);
  if (time) url.searchParams.set("time", Math.floor(time / 1000) + "000000000");
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Loki ${res.status}: ${await res.text()}`);
  return res.json();
}

function parseLogLines(data) {
  const streams = data?.data?.result ?? [];
  const rows = [];
  for (const s of streams) {
    for (const [ts, line] of s.values ?? []) {
      try { rows.push({ ts: Number(ts), ...JSON.parse(line) }); }
      catch { rows.push({ ts: Number(ts), raw: line }); }
    }
  }
  return rows.sort((a, b) => b.ts - a.ts);
}

function buildSelector(node) {
  return node && node !== "__all__"
    ? `{job="nginx", node="${node}"}`
    : `{job="nginx"}`;
}

// ─── Hooks ───────────────────────────────────────────────────────────────────
function useAsync(fn, deps) {
  const [state, setState] = useState({ loading: false, data: null, error: null });
  const run = useCallback(async () => {
    setState(s => ({ ...s, loading: true, error: null }));
    try {
      const data = await fn();
      setState({ loading: false, data, error: null });
    } catch (e) {
      setState({ loading: false, data: null, error: e.message });
    }
  }, deps);
  useEffect(() => { run(); }, [run]);
  return { ...state, refresh: run };
}

// ─── Styles ──────────────────────────────────────────────────────────────────
const css = `
  @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Syne:wght@400;700;800&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg:        #090c10;
    --bg2:       #0d1117;
    --bg3:       #161b22;
    --bg4:       #1c2330;
    --border:    #21262d;
    --border2:   #30363d;
    --text:      #e6edf3;
    --text2:     #8b949e;
    --text3:     #484f58;
    --accent:    #00d4a0;
    --accent2:   #0097ff;
    --warn:      #e3b341;
    --danger:    #f85149;
    --success:   #3fb950;
    --purple:    #bc8cff;
    --font-mono: 'JetBrains Mono', monospace;
    --font-ui:   'Syne', sans-serif;
    --radius:    6px;
    --radius2:   10px;
  }

  html, body { background: var(--bg); color: var(--text); font-family: var(--font-ui); min-height: 100vh; }

  .app { display: flex; flex-direction: column; min-height: 100vh; }

  /* ── Header ── */
  .header {
    display: flex; align-items: center; gap: 20px;
    padding: 14px 24px; border-bottom: 1px solid var(--border);
    background: var(--bg2); position: sticky; top: 0; z-index: 100;
  }
  .header-logo { font-size: 16px; font-weight: 800; letter-spacing: -0.5px; color: var(--accent); white-space: nowrap; }
  .header-logo span { color: var(--text2); font-weight: 400; }
  .header-controls { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-left: auto; }

  /* ── Controls ── */
  select, input[type=text] {
    background: var(--bg3); border: 1px solid var(--border2); color: var(--text);
    border-radius: var(--radius); padding: 6px 10px; font-family: var(--font-ui);
    font-size: 13px; outline: none; cursor: pointer;
  }
  select:focus, input:focus { border-color: var(--accent); }

  .btn {
    background: var(--accent); color: #000; border: none; border-radius: var(--radius);
    padding: 7px 16px; font-family: var(--font-ui); font-size: 13px; font-weight: 700;
    cursor: pointer; white-space: nowrap; transition: opacity 0.15s;
  }
  .btn:hover { opacity: 0.85; }
  .btn.secondary { background: var(--bg3); color: var(--text); border: 1px solid var(--border2); font-weight: 400; }
  .btn.danger { background: var(--danger); color: #fff; }

  /* ── Nav Tabs ── */
  .nav { display: flex; gap: 2px; padding: 0 24px; background: var(--bg2); border-bottom: 1px solid var(--border); overflow-x: auto; }
  .nav-tab {
    padding: 10px 16px; font-size: 13px; font-weight: 700; cursor: pointer;
    border-bottom: 2px solid transparent; color: var(--text2); white-space: nowrap;
    transition: color 0.15s, border-color 0.15s;
  }
  .nav-tab:hover { color: var(--text); }
  .nav-tab.active { color: var(--accent); border-bottom-color: var(--accent); }

  /* ── Layout ── */
  .main { padding: 20px 24px; display: flex; flex-direction: column; gap: 20px; }
  .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
  .grid-3 { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
  .grid-6 { display: grid; grid-template-columns: repeat(6, 1fr); gap: 12px; }
  @media (max-width: 900px) { .grid-2 { grid-template-columns: 1fr; } .grid-3 { grid-template-columns: 1fr; } .grid-6 { grid-template-columns: repeat(3, 1fr); } }

  /* ── Card ── */
  .card { background: var(--bg2); border: 1px solid var(--border); border-radius: var(--radius2); overflow: hidden; }
  .card-header { padding: 14px 18px 10px; display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid var(--border); }
  .card-title { font-size: 13px; font-weight: 700; color: var(--text2); text-transform: uppercase; letter-spacing: 0.5px; }
  .card-body { padding: 16px 18px; }

  /* ── Stat Cards ── */
  .stat { display: flex; flex-direction: column; gap: 4px; padding: 16px; border-radius: var(--radius2); background: var(--bg2); border: 1px solid var(--border); }
  .stat-label { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.6px; color: var(--text3); }
  .stat-value { font-size: 28px; font-weight: 800; font-family: var(--font-mono); line-height: 1; }
  .stat-sub { font-size: 11px; color: var(--text2); font-family: var(--font-mono); }
  .c-accent { color: var(--accent); }
  .c-warn { color: var(--warn); }
  .c-danger { color: var(--danger); }
  .c-success { color: var(--success); }
  .c-blue { color: var(--accent2); }
  .c-purple { color: var(--purple); }

  /* ── Table ── */
  .tbl-wrap { overflow-x: auto; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; font-family: var(--font-mono); }
  th { padding: 8px 10px; text-align: left; color: var(--text3); font-weight: 600; font-size: 11px; text-transform: uppercase; letter-spacing: 0.4px; border-bottom: 1px solid var(--border); white-space: nowrap; }
  td { padding: 7px 10px; border-bottom: 1px solid var(--border); color: var(--text2); vertical-align: top; word-break: break-all; max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  tr:hover td { background: var(--bg3); }
  tr:last-child td { border-bottom: none; }

  /* ── Status Badge ── */
  .badge { display: inline-block; padding: 1px 6px; border-radius: 3px; font-size: 11px; font-weight: 600; font-family: var(--font-mono); }
  .s-1xx { background: #1f2937; color: #9ca3af; }
  .s-2xx { background: #052e16; color: var(--success); }
  .s-3xx { background: #1c1f0a; color: var(--warn); }
  .s-4xx { background: #2d1a0e; color: #fb923c; }
  .s-5xx { background: #2d0e0e; color: var(--danger); }

  /* ── Chart ── */
  .chart-wrap { position